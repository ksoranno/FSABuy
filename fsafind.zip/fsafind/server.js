import express from "express";
import fetch from "node-fetch";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

// ── /api/search ──────────────────────────────────────────────────────────────
app.post("/api/search", async (req, res) => {
  const { query } = req.body;

  if (!query || typeof query !== "string" || query.trim().length === 0) {
    return res.status(400).json({ error: "query is required" });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "ANTHROPIC_API_KEY is not set on the server." });
  }

  const enc = encodeURIComponent(query.trim() + " FSA eligible");

  const system = `You are a price comparison assistant for FSA and HSA eligible health products.
You have deep knowledge of current US retail prices. Always respond with ONLY valid JSON — no markdown, no backticks, no explanation.`;

  const user = `Find prices for: "${query.trim()}"

Return ONLY this JSON structure (no extra text):
{
  "eligible": true,
  "eligibilityNote": "1-2 sentence FSA/HSA eligibility explanation",
  "results": [
    {
      "retailer": "Amazon",
      "productName": "Specific product name and size",
      "price": 24.99,
      "originalPrice": 34.99,
      "fsaEligible": true,
      "hsaEligible": true,
      "note": "Subscribe & Save available, free Prime shipping",
      "url": "https://www.amazon.com/s?k=${enc}"
    }
  ],
  "buyingTips": "3-4 sentences of practical buying advice"
}

Rules:
- Include 4-6 retailers from: Amazon, Walmart, CVS, Walgreens, Target, Rite Aid, FSAstore.com, HSAstore.com, Costco
- Only include retailers that realistically carry this product
- Use realistic current US market prices
- Sort results by price ascending (cheapest first)
- Omit originalPrice if no real discount applies
- Set eligible: false if the product is genuinely not FSA/HSA covered
- URLs must be real working search pages on each retailer`;

  try {
    const anthropicRes = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-opus-4-5",
        max_tokens: 1500,
        system,
        messages: [{ role: "user", content: user }],
      }),
    });

    if (!anthropicRes.ok) {
      const errBody = await anthropicRes.json().catch(() => ({}));
      console.error("Anthropic API error:", errBody);
      return res.status(502).json({ error: errBody?.error?.message || "Upstream API error" });
    }

    const data = await anthropicRes.json();
    const text = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("");

    const clean = text.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
    const parsed = JSON.parse(clean);
    res.json(parsed);
  } catch (err) {
    console.error("Search error:", err);
    res.status(500).json({ error: err.message || "Internal server error" });
  }
});

app.listen(PORT, () => {
  console.log(`FSAFind running at http://localhost:${PORT}`);
});
